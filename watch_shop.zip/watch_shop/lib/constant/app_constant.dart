class AppConstant {
  static const String appName = "toy shop";
}
